#ifndef FUNCIONES_H
#define FUNCIONES_H

void iniciar();
void finalizar();

#endif