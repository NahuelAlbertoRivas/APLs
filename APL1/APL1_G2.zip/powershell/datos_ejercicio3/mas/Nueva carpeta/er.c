int main(){

    elseelsesle
    else
    return 1
    else
    if
    return 0
}